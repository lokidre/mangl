// adding two slots

#include <iostream>


template <class slot_T, class meth_T>
class SignalImpl {
public :
	SignalImpl(slot_T *s, meth_T m) : slot_ptr_(s), meth_ptr_(m)
	{
	}

private :
	slot_T *slot_ptr_ ;
	meth_T meth_ptr_ ;


public :
	void operator ()()
	{
		(slot_ptr_->*meth_ptr_)() ;
	}

} ;


class Signal {
public :

	template <class slot_T, class meth_T>
	void connect ( slot_T *s, meth_T m )
	{ 
		SignalImpl<slot_T,meth_T> impl(s,m) ;
		impl() ;
	}

} ;



class Slot1 {
public :
	void meth()
	{
		std::cout << "Slot1::meth()" << std::endl ;
	}
} ;

class Slot2 {
public :
	void meth()
	{
		std::cout << "Slot2::meth()" << std::endl ;
	}
} ;




int main()
{
	Slot1 slot1 ;
	Slot2 slot2 ;

	Signal sig ;

	sig.connect(&slot1,&Slot1::meth) ;
	sig.connect(&slot2,&Slot2::meth) ;

	return 0 ;
}


