// basic idea

#include <iostream>


template <class Slot>
class Signal {
public :
	Signal ( Slot *s, void (Slot::*m)()) : slotPtr_(s), methPtr_(m) {}

private :
	Slot *slotPtr_ ;
	void (Slot::*methPtr_)() ;

public :
	void operator()()
	{
		(slotPtr_->*methPtr_)() ;
	}
} ;


class Slot {
public :
	void meth()
	{
		std::cout << "slot_class::slot_meth()" << std::endl ;
	}
} ;




int main()
{
	Slot slot ;

	Signal<Slot> sig(&slot,&Slot::meth) ;

	sig() ;

	return 0 ;
}

